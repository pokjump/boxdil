<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Wypożyczalnia Sprzętu Sportowego</title>
</head>
<body>
        <h1>Wypożyczalnia Sprzętu Sportowego</h1>
    <div class="menu">
        <nav>
            <ul>
                <li><a href="index.php">Strona Główna</a></li>
                <li><a href="regulamin.php">Regulamin</a></li>
                <li><a href="kontakt.php">Kontakt</a></li>
            </ul>
        </nav>
    </div>

    <table class="main">
        <tr>
            <td><a href="noga.php"><img src="photos/noga.jpeg" title="Piłka nożna"></a></td>
            <td><a href="ochraniacze.php"><img src="photos/ochr.jpg" title="Ochraniacze"></a></td>
        </tr>
        <tr>
            <td><a href="siatkowka.php"><img src="photos/siatka.jpg" title="Siatkówka"></a></td>
            <td><a href="rakiety.php"><img src="photos/tenis.jpeg" title="Tenis Ziemny"></a></td>
        </tr>
    </table>

    <footer>
        &copy; 2023 Wypożyczalnia Sprzętu Sportowego
    </footer>
</body>
</html>
