<?php
$polaczenie = new mysqli('localhost', 'root', '', 'wss') or die ("Nie można połączyć się z bazą danych");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $imie = $_POST['imie'];
    $nazwisko = $_POST['nazwisko'];
    $kod_pocztowy = $_POST['kodpocztowy'];
    $miejscowosc = $_POST['miejscowosc'];
    $ulica = $_POST['ulica'];
    $nr_domu = $_POST['nrdomu'];
    $email = $_POST['mail'];
    $telefon = $_POST['numertelefonu'];
    $data_wypozyczenia = $_POST['data_wypozyczenia'];
    $data_zwrotu = $_POST['data_zwrotu'];
    $marka = $_POST['marka'];
    $typ_sprzetu = $_POST['typ_sprzetu'];

    $zapytanie_id = "SELECT sprzet.sprzetID, sprzet.cena_za_dzien
                     FROM sprzet 
                     JOIN typ_sprzetu ON sprzet.typID = typ_sprzetu.typID
                     JOIN marka ON sprzet.markaID = marka.markaID
                     WHERE marka.nazwa = '$marka' AND typ_sprzetu.nazwa = '$typ_sprzetu'";
    $wynik_id = $polaczenie->query($zapytanie_id);

    if ($wynik_id->num_rows > 0) {
        $row_id = $wynik_id->fetch_assoc();
        $sprzetID = $row_id["sprzetID"];
        $cena_za_dzien = $row_id["cena_za_dzien"];

        $zapytanie_klient = "SELECT * FROM klienci WHERE email = '$email'";
        $wynik_klient = $polaczenie->query($zapytanie_klient);

        if ($wynik_klient->num_rows > 0) {
            $row = $wynik_klient->fetch_assoc();
            $klientID = $row["klientID"];
        } else {
            $zapytanie_dodaj_klienta = "INSERT INTO klienci (imie, nazwisko, kod_pocztowy, miejscowosc, ulica, nr_domu, email, telefon) 
                                        VALUES ('$imie', '$nazwisko', '$kod_pocztowy', '$miejscowosc', '$ulica', '$nr_domu', '$email', '$telefon')";
            
            if ($polaczenie->query($zapytanie_dodaj_klienta) === TRUE) {
                $klientID = $polaczenie->insert_id;
            } else {
                echo "Błąd podczas dodawania klienta: " . $polaczenie->error;
            }
        }

        $data_wypozyczenia_dt = new DateTime($data_wypozyczenia);
        $data_zwrotu_dt = new DateTime($data_zwrotu);
        $roznica = $data_wypozyczenia_dt->diff($data_zwrotu_dt);
        $ilosc_dni = $roznica->days + 1;
        $cena_calkowita = $ilosc_dni * $cena_za_dzien;

        $zapytanie_wypozyczenie = "INSERT INTO wypozyczenia (klientID, sprzetID, data_wypozyczenia, data_zwrotu, cena) 
                                  VALUES ('$klientID', '$sprzetID', '$data_wypozyczenia', '$data_zwrotu', '$cena_calkowita')";
                                  
        if ($polaczenie->query($zapytanie_wypozyczenie) === TRUE) {
            $wypozyczenieID = $polaczenie->insert_id;
            echo "<script>
                    var cena_calkowita = $cena_calkowita;
                    var wypozyczenieID = $wypozyczenieID;
                    var potwierdzenie = confirm('Wypożyczenie (ID: ' + wypozyczenieID + ') zostało pomyślnie zarejestrowane. Cena to ' + cena_calkowita + ' złotych. Czy chcesz kontynuować?');
                    if (potwierdzenie) {
                        window.location.href = 'index.php'; 
                    } else {
                    }
                  </script>";
        } else {

    }
    }}

$polaczenie->close();
?>
