-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Lis 27, 2023 at 08:11 PM
-- Wersja serwera: 10.4.28-MariaDB
-- Wersja PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wss`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `klienci`
--

CREATE TABLE `klienci` (
  `klientID` int(11) NOT NULL,
  `imie` text DEFAULT NULL,
  `nazwisko` text DEFAULT NULL,
  `kod_pocztowy` text DEFAULT NULL,
  `miejscowosc` text DEFAULT NULL,
  `ulica` text DEFAULT NULL,
  `nr_domu` text DEFAULT NULL,
  `email` text DEFAULT NULL,
  `telefon` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `marka`
--

CREATE TABLE `marka` (
  `markaID` int(11) NOT NULL,
  `nazwa` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `marka`
--

INSERT INTO `marka` (`markaID`, `nazwa`) VALUES
(1, 'Wilson'),
(2, 'Head'),
(3, 'Adidas'),
(4, 'Mikasa'),
(5, 'Molten'),
(6, 'Nike'),
(7, 'McDavid');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sprzet`
--

CREATE TABLE `sprzet` (
  `sprzetID` int(11) NOT NULL,
  `typID` int(11) DEFAULT NULL,
  `markaID` int(11) DEFAULT NULL,
  `cena_za_dzien` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `sprzet`
--

INSERT INTO `sprzet` (`sprzetID`, `typID`, `markaID`, `cena_za_dzien`) VALUES
(1, 1, 1, 16),
(2, 1, 2, 15),
(3, 2, 3, 10),
(4, 2, 6, 11),
(5, 3, 4, 13),
(6, 3, 5, 12),
(7, 4, 6, 9),
(8, 4, 7, 10);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `typ_sprzetu`
--

CREATE TABLE `typ_sprzetu` (
  `typID` int(11) NOT NULL,
  `nazwa` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `typ_sprzetu`
--

INSERT INTO `typ_sprzetu` (`typID`, `nazwa`) VALUES
(1, 'Rakieta do tenisa ziemnego'),
(2, 'Piłka do nogi'),
(3, 'Piłka do siatkówki'),
(4, 'Ochraniacze');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `wypozyczenia`
--

CREATE TABLE `wypozyczenia` (
  `wypozyczenieID` int(11) NOT NULL,
  `klientID` int(11) DEFAULT NULL,
  `sprzetID` int(11) DEFAULT NULL,
  `data_wypozyczenia` date DEFAULT NULL,
  `data_zwrotu` date DEFAULT NULL,
  `cena` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `klienci`
--
ALTER TABLE `klienci`
  ADD PRIMARY KEY (`klientID`);

--
-- Indeksy dla tabeli `marka`
--
ALTER TABLE `marka`
  ADD PRIMARY KEY (`markaID`);

--
-- Indeksy dla tabeli `sprzet`
--
ALTER TABLE `sprzet`
  ADD PRIMARY KEY (`sprzetID`),
  ADD KEY `typID` (`typID`),
  ADD KEY `markaID` (`markaID`);

--
-- Indeksy dla tabeli `typ_sprzetu`
--
ALTER TABLE `typ_sprzetu`
  ADD PRIMARY KEY (`typID`);

--
-- Indeksy dla tabeli `wypozyczenia`
--
ALTER TABLE `wypozyczenia`
  ADD PRIMARY KEY (`wypozyczenieID`),
  ADD KEY `klientID` (`klientID`),
  ADD KEY `sprzetID` (`sprzetID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `klienci`
--
ALTER TABLE `klienci`
  MODIFY `klientID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `marka`
--
ALTER TABLE `marka`
  MODIFY `markaID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `sprzet`
--
ALTER TABLE `sprzet`
  MODIFY `sprzetID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `typ_sprzetu`
--
ALTER TABLE `typ_sprzetu`
  MODIFY `typID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `wypozyczenia`
--
ALTER TABLE `wypozyczenia`
  MODIFY `wypozyczenieID` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sprzet`
--
ALTER TABLE `sprzet`
  ADD CONSTRAINT `sprzet_ibfk_1` FOREIGN KEY (`typID`) REFERENCES `typ_sprzetu` (`typID`),
  ADD CONSTRAINT `sprzet_ibfk_2` FOREIGN KEY (`markaID`) REFERENCES `marka` (`markaID`);

--
-- Constraints for table `wypozyczenia`
--
ALTER TABLE `wypozyczenia`
  ADD CONSTRAINT `wypozyczenia_ibfk_1` FOREIGN KEY (`klientID`) REFERENCES `klienci` (`klientID`),
  ADD CONSTRAINT `wypozyczenia_ibfk_2` FOREIGN KEY (`sprzetID`) REFERENCES `sprzet` (`sprzetID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
