<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Wypożyczalnia Sprzętu Sportowego</title>
</head>
<body>
        <h1>Wypożyczalnia Sprzętu Sportowego</h1>
    <div class="menu">
        <nav>
            <ul>
                <li><a href="index.php">Strona Główna</a></li>
                <li><a href="regulamin.php">Regulamin</a></li>
                <li><a href="kontakt.php">Kontakt</a></li>
            </ul>
        </nav>
    </div>

    <?php
    $polaczenie = new mysqli('localhost', 'root', '', 'wss') or die ("Nie mozna sie polaczyc z baza");
    $zapytanie = "SELECT sprzet.*, marka.nazwa AS marka_nazwa, typ_sprzetu.nazwa AS typ_nazwa
            FROM sprzet 
            JOIN marka ON sprzet.markaID = marka.markaID
            JOIN typ_sprzetu ON sprzet.typID = typ_sprzetu.typID
            WHERE marka.nazwa = 'Adidas' AND typ_sprzetu.nazwa = 'Piłka do nogi'";
    $wynik = $polaczenie->query($zapytanie);
    if ($wynik->num_rows > 0) {
        $row = $wynik->fetch_assoc();
        echo "<h2>Informacje o produkcie</h2>";
        echo "<p>Marka: " . $row["marka_nazwa"] . "</p>";
        echo "<p>Typ: " . $row["typ_nazwa"] . "</p>";
        echo "<p>Cena za dzień: " . $row["cena_za_dzien"] . " złotych". "</p>";
    } 
    $polaczenie->close();
    ?>

    <form action="wypozycz.php" method="post">
        <h2>Wypożycz Piłkę do nogi Adidas</h2>
        Imię: <input type="text" name="imie" required> 
        Nazwisko: <input type="text" name="nazwisko" required> 
        Kod pocztowy: <input type="text" name="kodpocztowy" required> 
        Miejscowość: <input type="text" name="miejscowosc" required>
        Ulica: <input type="text" name="ulica" required> 
        Numer domu: <input type="text" name="nrdomu" required> 
        Adres e-mail: <input type="email" name="mail" required> 
        Numer telefonu: <input type="number" name="numertelefonu" required> 
        <label for="data_wypozyczenia">Data Wypożyczenia:</label>
        <input type="date" name="data_wypozyczenia" required>
        <label for="data_zwrotu">Data Zwrotu:</label>
        <input type="date" name="data_zwrotu" required>
        <input type="hidden" name="marka" value="Adidas">
        <input type="hidden" name="typ_sprzetu" value="Piłka do nogi">
        
        <button type="submit">Wypożycz</button><br><br>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $cena_za_dzien = $row["cena_za_dzien"];
        $data_wypozyczenia = ($_POST['data_wypozyczenia']);
        $data_zwrotu = ($_POST['data_zwrotu']);
        $roznica = $data_wypozyczenia->diff($data_zwrotu);
        $ilosc_dni = $roznica->days + 1; 
        $cena_calkowita = $ilosc_dni * $cena_za_dzien;
    }
    ?>

    <footer>
        &copy; 2023 Wypożyczalnia Sprzętu Sportowego
    </footer>
</body>
</html>
