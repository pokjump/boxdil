<?php
$polaczenie = new mysqli('localhost', 'root', '', 'wss') or die ("Nie mozna sie polaczyc z baza");

$zapytanie1 = $polaczenie->query("SELECT cena_za_dzien 
                                  FROM sprzet 
                                  WHERE markaID=6 AND typID=4");
$zapytanie2 = $polaczenie->query("SELECT cena_za_dzien 
                                  FROM sprzet WHERE markaID=7");

$wynik1 = $zapytanie1->fetch_assoc();
$cenawilson = $wynik1['cena_za_dzien'];

$wynik2 = $zapytanie2->fetch_assoc();
$cenahead = $wynik2['cena_za_dzien'];

$polaczenie->close();
?>

<!DOCTYPE html>
<html lang="pl">
<head>
<script>
    function wypozycz(strona) {
        window.location.href = strona ;
    }
</script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Wypożyczalnia Sprzętu Sportowego</title>
</head>
<body>
        <h1>Wypożyczalnia Sprzętu Sportowego</h1>
    <div class="menu">
        <nav>
            <ul>
                <li><a href="index.php">Strona Główna</a></li>
                <li><a href="regulamin.php">Regulamin</a></li>
                <li><a href="kontakt.php">Kontakt</a></li>
            </ul>
        </nav>
    </div>
    <h1>Ochraniacze</h1>
    <table class="rakiety">
        <tr>
    <td><div class="rakietki">
        <img src="photos/ochrnike.png">
        <h3>Nike</h3>
        <?php echo "<p>Cena za dzień: $cenawilson"." złotych</p>";?>
        <button type="button" onclick="wypozycz('wypozyczochrnike.php')">Wypożycz</button>
    </div>
</td>
<td><div class="rakietki">
        <img src="photos/ochrmcd.jpg">
        <h3>McDavid</h3>
        <?php echo "<p>Cena za dzień: $cenahead"." złotych</p>";?>
        <button type="submit" onclick="wypozycz('wypozyczochrmcd.php')">Wypożycz</button>
    </div>
</tr>
</table>
<br>
    <footer>
        &copy; 2023 Wypożyczalnia Sprzętu Sportowego
    </footer>
</body>
</html>
