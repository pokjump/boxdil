<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Wypożyczalnia Sprzętu Sportowego</title>
</head>
<body>
        <h1>Wypożyczalnia Sprzętu Sportowego</h1>
    <div class="menu">
        <nav>
            <ul>
                <li><a href="index.php">Strona Główna</a></li>
                <li><a href="regulamin.php">Regulamin</a></li>
                <li><a href="kontakt.php">Kontakt</a></li>
            </ul>
        </nav>
    </div>

<div class="formularz">
    <h2>Formularz Kontaktowy</h2>
    <form method="post" action="mailto: kontakt@wss.pl">
        <label for="imie">Imię:</label>
        <input type="text" id="imie" name="imie" required>

        <label for="nazwisko">Nazwisko:</label>
        <input type="text" id="nazwisko" name="nazwisko" required>

        <label for="email">E-mail:</label>
        <input type="email" id="email" name="email" required>

        <label for="telefon">Telefon:</label>
        <input type="tel" id="telefon" name="telefon" required>

        <label for="temat">Temat:</label>
        <input type="text" id="temat" name="temat" required>

        <label for="tresc">Treść wiadomości:</label>
        <textarea id="tresc" name="tresc" rows="6" required></textarea>
        <br>
        <button type="submit">Wyślij</button>
    </form>
</div>

    <footer>
        &copy; 2023 Wypożyczalnia Sprzętu Sportowego
    </footer>
</body>
</html>
