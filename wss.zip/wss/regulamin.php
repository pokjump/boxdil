<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Wypożyczalnia Sprzętu Sportowego</title>
</head>
<body>
        <h1>Wypożyczalnia Sprzętu Sportowego</h1>
    <div class="menu">
        <nav>
            <ul>
                <li><a href="index.php">Strona Główna</a></li>
                <li><a href="regulamin.php">Regulamin</a></li>
                <li><a href="kontakt.php">Kontakt</a></li>
            </ul>
        </nav>
    </div>
    <h1>Regulamin Wypożyczalni Sprzętu Sportowego</h1>

    <h2>1. Postanowienia ogólne</h2>
    <p>1.1 Niniejszy regulamin określa zasady wypożyczania sprzętu sportowego w naszej wypożyczalni.</p>
    <p>1.2 Wypożyczenie sprzętu możliwe jest po złożeniu odpowiednich dokumentów tożsamości.</p>

    <h2>2. Warunki wypożyczenia</h2>
    <p>2.1 Wypożyczalnia udostępnia sprzęt w stanie sprawności technicznej.</p>
    <p>2.2 Wypożyczający zobowiązany jest do zwrócenia sprzętu w stanie nie gorszym niż był w chwili wypożyczenia.</p>

    <h2>3. Opłaty</h2>
    <p>3.1 Wypożyczenie sprzętu wiąże się z uiszczeniem opłaty określonej w cenniku wypożyczalni.</p>
    <p>3.2 Opóźnienia w zwrocie sprzętu podlegają karze finansowej zgodnie z obowiązującym cennikiem.</p>

    <h2>4. Odpowiedzialność</h2>
    <p>4.1 Wypożyczający ponosi pełną odpowiedzialność za szkody wyrządzone sprzętowi w trakcie wypożyczenia.</p>
    <p>4.2 W razie uszkodzenia sprzętu, wypożyczający zobowiązany jest do pokrycia kosztów naprawy.</p>

    <h2>5. Zasady bezpieczeństwa</h2>
    <p>5.1 Wypożyczający zobowiązany jest do przestrzegania zasad bezpieczeństwa podczas korzystania z wypożyczonego sprzętu.</p>
    <p>5.2 W przypadku naruszenia zasad bezpieczeństwa, wypożyczający może zostać pozbawiony prawa do dalszego korzystania z wypożyczalni.</p>

    <footer>
        &copy; 2023 Wypożyczalnia Sprzętu Sportowego
    </footer>
</body>
</html>
