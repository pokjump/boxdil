<?php
$polaczenie = new mysqli('localhost', 'root', '', 'wss') or die ("Nie mozna sie polaczyc z baza");

$zapytanie1 = $polaczenie->query("SELECT cena_za_dzien 
                                  FROM sprzet 
                                  WHERE markaID=1");
$zapytanie2 = $polaczenie->query("SELECT cena_za_dzien 
                                  FROM sprzet WHERE markaID=2");

$wynik1 = $zapytanie1->fetch_assoc();
$cenawilson = $wynik1['cena_za_dzien'];

$wynik2 = $zapytanie2->fetch_assoc();
$cenahead = $wynik2['cena_za_dzien'];

$polaczenie->close();
?>

<!DOCTYPE html>
<html lang="pl">
<head>
<script>
    function wypozycz(strona) {
        window.location.href = strona ;
    }
</script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Wypożyczalnia Sprzętu Sportowego</title>
</head>
<body>
        <h1>Wypożyczalnia Sprzętu Sportowego</h1>
    <div class="menu">
        <nav>
            <ul>
                <li><a href="index.php">Strona Główna</a></li>
                <li><a href="regulamin.php">Regulamin</a></li>
                <li><a href="kontakt.php">Kontakt</a></li>
            </ul>
        </nav>
    </div>
    <h1>Rakiety do tenisa ziemnego</h1>
    <table class="rakiety">
        <tr>
    <td><div class="rakietki">
        <img src="photos/wilson.jpg">
        <h3>Wilson</h3>
        <?php echo "<p>Cena za dzień: $cenawilson"." złotych</p>";?>
        <button type="button" onclick="wypozycz('wypozyczwilson.php')">Wypożycz</button>
    </div>
</td>
<td><div class="rakietki">
        <img src="photos/head.jpg">
        <h3>Head</h3>
        <?php echo "<p>Cena za dzień: $cenahead"." złotych</p>";?>
        <button type="submit" onclick="wypozycz('wypozyczhead.php')">Wypożycz</button>
    </div>
</tr>
</table>
<br>
    <footer>
        &copy; 2023 Wypożyczalnia Sprzętu Sportowego
    </footer>
</body>
</html>
